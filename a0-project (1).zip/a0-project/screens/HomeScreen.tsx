import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ImageBackground,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons, Ionicons, FontAwesome5 } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

const BattleRoyaleLobby = () => {
  const [selectedCharacter, setSelectedCharacter] = useState(0);
  const [currency, setCurrency] = useState(2500);
  
  const characters = [
    { name: 'Shadow Elite', level: 42 },
    { name: 'Cyber Warrior', level: 38 },
    { name: 'Stealth Ops', level: 45 },
  ];

  const leaderboardData = [
    { name: 'ProGamer123', score: 2500, rank: 1 },
    { name: 'NinjaWarrior', score: 2350, rank: 2 },
    { name: 'BattleMaster', score: 2200, rank: 3 },
  ];

  return (
    <View style={styles.container}>
      <ImageBackground
        source={{ uri: 'https://api.a0.dev/assets/image?text=futuristic%20cyberpunk%20city%20at%20night%20with%20neon%20lights%20and%20military%20base&aspect=16:9' }}
        style={styles.background}
      >
        <LinearGradient
          colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0.7)']}
          style={styles.overlay}
        >
          {/* Top Bar */}
          <View style={styles.topBar}>
            <View style={styles.profileSection}>
              <Image
                source={{ uri: 'https://api.a0.dev/assets/image?text=futuristic%20soldier%20profile%20avatar&aspect=1:1' }}
                style={styles.profilePic}
              />
              <View style={styles.userInfo}>
                <Text style={styles.username}>Commander_X</Text>
                <View style={styles.levelBar}>
                  <View style={styles.levelProgress} />
                  <Text style={styles.levelText}>LVL 42</Text>
                </View>
              </View>
            </View>
            <View style={styles.currencyContainer}>
              <MaterialCommunityIcons name="diamond-stone" size={24} color="#00ffff" />
              <Text style={styles.currencyText}>{currency}</Text>
            </View>
          </View>

          {/* Event Banner */}
          <View style={styles.eventBannerContainer}>
            <Image
              source={{ uri: 'https://api.a0.dev/assets/image?text=futuristic%20battle%20royale%20event%20banner%20with%20rewards&aspect=16:9' }}
              style={styles.eventBanner}
            />
            <View style={styles.eventInfo}>
              <Text style={styles.eventTitle}>CYBER WARFARE EVENT</Text>
              <Text style={styles.eventSubtitle}>Limited Time Rewards!</Text>
            </View>
          </View>

          {/* Character Selection */}
          <View style={styles.characterSection}>
            <Image
              source={{ uri: 'https://api.a0.dev/assets/image?text=futuristic%20soldier%20in%20tactical%20gear%20holding%20advanced%20weapon&aspect=1:1' }}
              style={styles.characterImage}
            />
            <View style={styles.characterControls}>
              <TouchableOpacity style={styles.characterButton}>
                <Ionicons name="chevron-back" size={24} color="white" />
              </TouchableOpacity>
              <View style={styles.characterInfo}>
                <Text style={styles.characterName}>{characters[selectedCharacter].name}</Text>
                <Text style={styles.characterLevel}>Level {characters[selectedCharacter].level}</Text>
              </View>
              <TouchableOpacity style={styles.characterButton}>
                <Ionicons name="chevron-forward" size={24} color="white" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Leaderboard */}
          <View style={styles.leaderboardContainer}>
            <Text style={styles.leaderboardTitle}>TOP PLAYERS</Text>
            {leaderboardData.map((player, index) => (
              <View key={index} style={styles.leaderboardItem}>
                <Text style={styles.rankText}>#{player.rank}</Text>
                <Text style={styles.playerName}>{player.name}</Text>
                <Text style={styles.scoreText}>{player.score}</Text>
              </View>
            ))}
          </View>

          {/* Bottom Bar */}
          <View style={styles.bottomBar}>
            <TouchableOpacity style={styles.iconButton}>
              <Ionicons name="settings-outline" size={28} color="white" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.startButton}>
              <LinearGradient
                colors={['#00ffff', '#0088ff']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.startGradient}
              >
                <Text style={styles.startText}>START GAME</Text>
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton}>
              <FontAwesome5 name="store" size={24} color="white" />
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    width: '100%',
  },
  overlay: {
    flex: 1,
    padding: 16,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 40,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profilePic: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#00ffff',
  },
  userInfo: {
    marginLeft: 10,
  },
  username: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  levelBar: {
    width: 100,
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 3,
    marginTop: 4,
  },
  levelProgress: {
    width: '75%',
    height: '100%',
    backgroundColor: '#00ffff',
    borderRadius: 3,
  },
  levelText: {
    color: '#00ffff',
    fontSize: 12,
    position: 'absolute',
    right: 0,
    top: 8,
  },
  currencyContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 8,
    borderRadius: 20,
  },
  currencyText: {
    color: 'white',
    marginLeft: 6,
    fontSize: 16,
    fontWeight: 'bold',
  },
  eventBannerContainer: {
    height: height * 0.15,
    marginTop: 20,
    borderRadius: 10,
    overflow: 'hidden',
  },
  eventBanner: {
    width: '100%',
    height: '100%',
  },
  eventInfo: {
    position: 'absolute',
    bottom: 10,
    left: 10,
  },
  eventTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textShadowColor: 'rgba(0,0,0,0.75)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  eventSubtitle: {
    color: '#00ffff',
    fontSize: 14,
    textShadowColor: 'rgba(0,0,0,0.75)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  characterSection: {
    alignItems: 'center',
    marginTop: 20,
  },
  characterImage: {
    width: width * 0.5,
    height: width * 0.5,
    borderRadius: width * 0.25,
    borderWidth: 2,
    borderColor: '#00ffff',
  },
  characterControls: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  characterButton: {
    padding: 10,
  },
  characterInfo: {
    alignItems: 'center',
    marginHorizontal: 20,
  },
  characterName: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  characterLevel: {
    color: '#00ffff',
    fontSize: 14,
  },
  leaderboardContainer: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 10,
    padding: 15,
    marginTop: 20,
  },
  leaderboardTitle: {
    color: '#00ffff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  leaderboardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  rankText: {
    color: '#00ffff',
    width: 40,
    fontSize: 14,
  },
  playerName: {
    color: 'white',
    flex: 1,
    fontSize: 14,
  },
  scoreText: {
    color: '#00ffff',
    fontSize: 14,
  },
  bottomBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 'auto',
    paddingVertical: 20,
  },
  iconButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  startButton: {
    flex: 1,
    marginHorizontal: 20,
    height: 50,
    borderRadius: 25,
    overflow: 'hidden',
  },
  startGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  startText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
});

export default BattleRoyaleLobby;